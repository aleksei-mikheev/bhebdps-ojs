import { Weapon } from './Weapon.js'

export class Sword extends Weapon{
    constructor() {
        super('Меч', 25, 500, 1);
    }
}
